function changelocation(){


return `<div id="sd-location">

    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
  <div>
    <a href="./grocery.html">Grocery & Staples</a>
  </div>
  <div>
    <a href="./vegetable_fruits.html">Vegetables & fruits</a>
  </div>
  <div>
    <a href="./personalCare.html">Personal Care</a>
  </div>
  <div>
    <a href="./colddrink.html">Cold drinks & juices</a>
  </div>
  <div>
    <a href="">household items</a>
  </div>
  <div>
    <a href="">noodles, sauces & instant food</a>
  </div>
  <div>
    <a href="">bakery & biscuits</a>
  </div>

  <div>
    <select style="border: none;" >
        <option value="">More</option>
        <option value=""></option>
        <option value=""></option>
        <option value=""></option>
    </select>
  </div>
  <div></div>
  <div></div>
  <div></div>
  <div></div>
  <div></div>
  <div></div>


</div>`



}

function changelocation2(){


    return `<div id="sd-location">
    
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
  <div>
    <a href="../grocery.html">Grocery & Staples</a>
  </div>
  <div>
    <a href="../vegetable_fruits.html">Vegetables & fruits</a>
  </div>
  <div>
    <a href="../personalCare.html">Personal Care</a>
  </div>
  <div>
    <a href="../colddrink.html">Cold drinks & juices</a>
  </div>
  <div>
    <a href="">household items</a>
  </div>
  <div>
    <a href="">noodles, sauces & instant food</a>
  </div>
  <div>
    <a href="">bakery & biscuits</a>
  </div>

  <div>
    <select style="border: none;" >
        <option value="">More</option>
        <option value=""></option>
        <option value=""></option>
        <option value=""></option>
    </select>
  </div>
  <div></div>
  <div></div>
  <div></div>
  <div></div>
  <div></div>
  <div></div>


</div>`
    
    
    
    }

export   {changelocation,changelocation2}